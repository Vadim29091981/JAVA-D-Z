import java.util.LinkedList;
import java.util.Queue;

class NightClubBouncer {
    public static void main(String[] args) {
        Queue<Visitor> visitorQueue = new LinkedList<>();

        // Добавим несколько посетителей в очередь
        visitorQueue.add(new Visitor("Петя", 20));
        visitorQueue.add(new Visitor("Вася", 25));
        visitorQueue.add(new Visitor("Катя", 18));
        visitorQueue.add(new Visitor("Оля", 22));

        while (!visitorQueue.isEmpty()) {
            Visitor currentVisitor = visitorQueue.poll();
            if (currentVisitor.getAge() >= 21) {
                System.out.println(currentVisitor.getName() + " впущен в клуб.");
            } else {
                System.out.println(currentVisitor.getName() + " не впущен в клуб, так как ему меньше 21 года.");
            }
        }
    }
}

