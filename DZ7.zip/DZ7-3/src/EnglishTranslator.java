import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class EnglishTranslator {
    public static void main(String[] args) {
        Map<String, String> dictionary = new HashMap<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Введите слово на английском (или 'stopTranslate' для завершения): ");
            String englishWord = scanner.nextLine().trim();

            if (englishWord.equalsIgnoreCase("stopTranslate")) {
                break;
            }

            if (dictionary.containsKey(englishWord)) {
                String translation = dictionary.get(englishWord);
                System.out.println("Перевод: " + translation);
            } else {
                System.out.println("Слово не найдено в словаре. Введите перевод: ");
                String translation = scanner.nextLine().trim();
                dictionary.put(englishWord, translation);
                System.out.println("Слово и его перевод добавлены в словарь.");
            }
        }

        System.out.println("Программа завершена.");
    }
}