import java.util.Scanner;

public class BreakfastAtGrandmas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите возраст внука: ");
        int age = scanner.nextInt();

        int pancakesEaten = 0;

        System.out.println("Бабушка начинает жарить блинчики...");

        while (age > 0) {
            System.out.println("Бабушка жарит 2 блинчика.");
            pancakesEaten++; // Внук съедает один блинчик.
            age--; // Уменьшаем возраст внука.
            System.out.println("Внук съел блинчик. Осталось блинов: " + age);
        }

        System.out.println("Внук наелся! Всего съедено блинов: " + pancakesEaten);
    }
}