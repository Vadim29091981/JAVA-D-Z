import java.util.*;

class FullName implements Comparable<FullName> {
    private String firstName;
    private String lastName;

    public FullName(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    @Override
    public int compareTo(FullName other) {
        return this.firstName.compareTo(other.getFirstName());
    }

    @Override
    public String toString() {
        return firstName + " " + lastName;
    }
}