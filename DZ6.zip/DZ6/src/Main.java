import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        TreeSet<FullName> fullNameSet = new TreeSet<>();
        fullNameSet.add(new FullName("John", "Doe"));
        fullNameSet.add(new FullName("Alice", "Smith"));
        fullNameSet.add(new FullName("Bob", "Johnson"));

        for (FullName fullName : fullNameSet) {
            System.out.println(fullName);
        }
    }
}