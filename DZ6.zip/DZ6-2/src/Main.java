import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<String> collection = new ArrayList<>();
        collection.add("Element 1");
        collection.add("Element 2");
        collection.add("Element 3");

        // Итерация с помощью цикла while и итератора
        Iterator<String> iterator = collection.iterator();
        while (iterator.hasNext()) {
            String element = iterator.next();
            System.out.println(element);
        }

        // Итерация с помощью цикла for и итератора
        for (Iterator<String> it = collection.iterator(); it.hasNext(); ) {
            String element = it.next();
            System.out.println(element);
        }
    }
}