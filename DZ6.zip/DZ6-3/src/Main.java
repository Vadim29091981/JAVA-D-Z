import java.util.Arrays;
import java.util.Iterator;

public class Main {
    public static void main(String[] args) {
        int[] numbers = {5, 2, 8, 1, 9};

        Arrays.sort(numbers); // Сначала сортируем массив по возрастанию

        // Создаем итератор, который будет выводить элементы в порядке убывания
        Iterator<Integer> descendingIterator = new Iterator<Integer>() {
            private int index = numbers.length - 1;

            @Override
            public boolean hasNext() {
                return index >= 0;
            }

            @Override
            public Integer next() {
                return numbers[index--];
            }
        };

        while (descendingIterator.hasNext()) {
            System.out.println(descendingIterator.next());
        }
    }
}