import java.util.ArrayList;

public class CountPositiveNumbers {
    public static int countPositive(ArrayList<Integer> list) {
        int count = 0;
        for (int num : list) {
            if (num > 0) {
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(-1);
        list.add(2);
        list.add(-3);
        list.add(4);
        list.add(-5);

        int positiveCount = countPositive(list);
        System.out.println("Количество положительных чисел: " + positiveCount);
    }
}