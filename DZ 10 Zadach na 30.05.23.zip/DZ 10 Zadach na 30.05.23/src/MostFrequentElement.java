import java.util.HashMap;
import java.util.Map;

public class MostFrequentElement {
    public static int findMostFrequent(int[] arr) {
        Map<Integer, Integer> frequencyMap = new HashMap<>();
        int mostFrequentElement = arr[0];
        int maxFrequency = 1;

        for (int num : arr) {
            int frequency = frequencyMap.getOrDefault(num, 0) + 1;
            frequencyMap.put(num, frequency);

            if (frequency > maxFrequency) {
                maxFrequency = frequency;
                mostFrequentElement = num;
            }
        }

        return mostFrequentElement;
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 2, 2, 4, 5, 2};
        int mostFrequent = findMostFrequent(arr);
        System.out.println("Наиболее часто встречающийся элемент: " + mostFrequent);
    }
}
