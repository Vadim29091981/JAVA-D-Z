import java.util.ArrayList;

public class ArrayListSum {
    public static int getArrayListSum(ArrayList<Integer> list) {
        int sum = 0;
        for (int num : list) {
            sum += num;
        }
        return sum;
    }

    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);

        int sum = getArrayListSum(list);
        System.out.println("Сумма элементов списка: " + sum);
    }
}