import java.util.ArrayList;
import java.util.Iterator;

public class RemoveEvenNumbers {
    public static void removeEven(ArrayList<Integer> list) {
        Iterator<Integer> iterator = list.iterator();
        while (iterator.hasNext()) {
            int num = iterator.next();
            if (num % 2 == 0) {
                iterator.remove();
            }
        }
    }

    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);

        removeEven(list);
        System.out.println("Список после удаления четных чисел: " + list);
    }
}