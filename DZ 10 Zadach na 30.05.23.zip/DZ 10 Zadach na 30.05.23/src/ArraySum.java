public class ArraySum {
    public static int getArraySum(int[] arr) {
        int sum = 0;
        for (int num : arr) {
            sum += num;
        }
        return sum;
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        int sum = getArraySum(arr);
        System.out.println("Сумма элементов массива: " + sum);
    }
}