import java.util.Arrays;

public class MinMaxArray {
    public static void findMinMax(int[] arr) {
        Arrays.sort(arr);
        int min = arr[0];
        int max = arr[arr.length - 1];
        System.out.println("Наименьшее значение: " + min);
        System.out.println("Наибольшее значение: " + max);
    }

    public static void main(String[] args) {
        int[] arr = {5, 2, 9, 1, 7};
        findMinMax(arr);
    }
}
