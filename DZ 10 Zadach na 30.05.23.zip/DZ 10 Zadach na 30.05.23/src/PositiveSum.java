public class PositiveSum {
    public static int getPositiveSum(int[] arr) {
        int sum = 0;
        for (int num : arr) {
            if (num > 0) {
                sum += num;
            }
        }
        return sum;
    }

    public static void main(String[] args) {
        int[] arr = {-1, 2, -3, 4, -5};
        int positiveSum = getPositiveSum(arr);
        System.out.println("Сумма положительных элементов: " + positiveSum);
    }
}